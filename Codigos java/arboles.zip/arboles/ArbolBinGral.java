import java.util.Scanner;

// Clase nodo utilizada para crear los nodos del arbol binario...
class Nodo
  {
   public Integer dato;
   public Nodo hijoIzq;
   public Nodo hijoDer;

   public Nodo() //Construye un nodo con valores nulos para el dato y sus hijos izq y der
      {
       dato=null;
       hijoIzq=null;
       hijoDer=null;
      }

   public Nodo(Integer dato) // Construye un nodo con un dato distinto de null y valores nulos
     {                       // para sus hijos izq y der
   	  this.dato=dato;
   	  hijoIzq=null;
   	  hijoDer=null;
     }

   public Nodo(Integer dato, Nodo hijoIzq, Nodo hijoDer)
     {                      // Construye un nodo con valores NO-NULOS
   	  this.dato=dato;
   	  this.hijoIzq=hijoIzq;
   	  this.hijoDer=hijoDer;
     }
  }


// Clase que genera un arbol binario general
public class ArbolBinGral
 {
   public Nodo raiz;  // La raiz del arbol binario

   public ArbolBinGral() // Constructor que genera un arbol binario nulo
     {
      raiz=null;
     }

   public ArbolBinGral(Nodo raiz) // Constructor que genera un arbol binario con un solo nodo
     {                            // que es la raiz
      this.raiz=raiz;
     }

   // Metodo recursivo utilizado para crear los hijos izq y der de un nodo en un arbol binario
   // La condicion de paro es un numero entero negativo que en el programa significa que
   // un nodo corriente no tendr� hijo izq, der o ambos.
   private void creaHijos(Nodo n)
     {
      int num;
      Scanner sc=new Scanner(System.in);
      System.out.println("Dame su hijo izquierdo de "+n.dato+":");
      num=sc.nextInt();

      if(num>=0)
        {
         n.hijoIzq=new Nodo(num);
         this.creaHijos(n.hijoIzq);
        }

      System.out.println("Dame su hijo derecho de "+n.dato+":");
      num=sc.nextInt();
      if(num>=0)
        {
         n.hijoDer=new Nodo(num);
         this.creaHijos(n.hijoDer);
        }

     }

   // metodo recursivo que recorre el arbol binario EnOrden...
   public void enOrden(Nodo n)
	  {
	   if (n!=null)
	    {
	     enOrden(n.hijoIzq);
	     System.out.print("--> "+((Integer)n.dato).intValue());
	     enOrden(n.hijoDer);
	    }
	  }


   public static void main(String args[])
      {
       int num;
       Scanner sc=new Scanner(System.in);

       ArbolBinGral arbol=new ArbolBinGral(); // Se crea un arbol binario nulo...

       System.out.println("Dame un numero entero positivo: ");
       num=sc.nextInt();

       if ((arbol.raiz==null)&&(num>=0))
         {
          arbol.raiz=new Nodo(num); // Se crea un primer nodo el cual ser� la raiz del arbol binario
          arbol.creaHijos(arbol.raiz); // Se empiezan a crear los hijos del nodo raiz recursivamente
         }
       arbol.enOrden(arbol.raiz); // se recorre el arbol binario creado y se muestra en pantalla
      }                           // dicho recorrido
 }
