
public class ListaLig
   {
    Nodo cabeza;
    int tamLista;

    public ListaLig()
      {
       cabeza=null;
       tamLista=0;
       System.out.println("Se ha creado una lista vacia!!!...\n");
      }

    public void InsertaInicio(int num)
      {
       Nodo n=new Nodo(num);
       n.sig=cabeza;
       cabeza=n;
       tamLista++;
       System.out.print("Dato "+num+" insertado al inicio de la lista ligada...\n"); 
      }
    

    public void InsertaFinal(int num)
      {
       if (cabeza==null)
          InsertaInicio(num) ;
       else {
             Nodo aux=cabeza;
             Nodo n=new Nodo(num);
             while(aux.sig!=null)
                 aux=aux.sig;
             aux.sig=n;
             System.out.print("Dato "+num+" insertado al FINAL de la lista ligada...\n");
             tamLista++;
            }
       
      }

    public void Inserta(int num, int posicion)
      {
       if (posicion<=1)
          InsertaInicio(num);
       else {
              if (posicion>tamLista)
                  InsertaFinal(num);
              else {
                    Nodo aux=cabeza;
                    Nodo n=new Nodo(num);
                    for(int i=1;i<(posicion-1);i++)
                         aux=aux.sig;
                    n.sig=aux.sig;
                    aux.sig=n;
                    System.out.print("Dato "+num+" insertado en la posicion "+posicion+ " de la lista ligada...\n");
                    tamLista++;
                   }
             }
      }

    public void eliminaInicio()
      {
       if (cabeza==null)
          System.out.print("Lista ligada vacia!!!\n");
       else { 
             System.out.print("El numero "+cabeza.num+" se ha eliminado de la lista\n");
             cabeza=cabeza.sig;
             tamLista--;
            }
      }

    public void eliminaFinal()
     {
      if (cabeza==null)
          System.out.print("Lista Vacía...\n");
      else{
            Nodo aux=cabeza; 
            for(int i=1;i<(tamLista-1);i++)
                 aux=aux.sig;
            System.out.print("Dato "+aux.sig.num+" eliminado al FINAL de la lista ligada...\n");
             aux.sig=null;
             tamLista--;
          }
     }

    public void elimina(int posicion)
      {
        if (posicion<=1)
          eliminaInicio();
       else {
              if (posicion>tamLista)
                  eliminaFinal();
              else {
                    Nodo aux=cabeza;
                    for(int i=1;i<(posicion-1);i++)
                         aux=aux.sig;
                    System.out.print("Dato "+aux.sig.num+" eliminado en la posicion "+posicion+ " de la lista ligada...\n");
                    aux.sig=aux.sig.sig;
                    tamLista--;
                   }
             }
      }

    public void recorreLista()
      {
       if (cabeza==null)
          System.out.print("Lista Vacía...\n");
       else {
             Nodo aux=cabeza;
             
             while(aux!=null)
               {
                 System.out.print("-->"+aux.num);
                 aux=aux.sig;
                }
              System.out.print("\n");
            }
            
      }

  
     public static void main(String args[])
       {
        ListaLig l=new ListaLig();

        l.InsertaFinal(4);
        l.InsertaInicio(10);
        l.InsertaInicio(3);
        l.InsertaInicio(8);
        l.InsertaFinal(43);
        l.InsertaFinal(1); 
        l.recorreLista();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.Inserta(5,7);
        l.Inserta(7,1);
        l.recorreLista();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.Inserta(100,4);
        l.recorreLista();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.Inserta(15,3);
        l.recorreLista();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.eliminaInicio();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.eliminaInicio();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.eliminaFinal();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.eliminaFinal();
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.recorreLista();
        l.elimina(3);
        System.out.println("\n TAMANIO DE LA LISTA = "+l.tamLista+" NODOS...");
        l.recorreLista();
       }  

   }  
