
public class Nodo
   {
    int num;
    Nodo sig;

    public Nodo(int num, Nodo sig)
       {
        this.num=num;
        this.sig=sig;
       }

    public Nodo(int num)
      {
       this.num=num;
       sig=null;
      }

    public Nodo()
      {
       num=-1;
       sig=null;
      }   
   }



