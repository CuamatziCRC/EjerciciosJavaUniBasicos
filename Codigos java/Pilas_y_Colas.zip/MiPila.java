
import java.util.Scanner;

class MiPila
   {
    public Object[] pila;
    int tope, tam;
    public Scanner leer; 

    public MiPila(int tam)
     {
      leer=new Scanner(System.in);
      pila=new Object[tam];
      this.tam=tam;
      tope=-1;
     }

    public void push(Object dato)
     {
      if (tope==(tam-1))
        System.out.println("ERROR: La Pila esta llena. Dato no apilado!...\n");
      else {
            tope++;
            pila[tope]=dato;
            System.out.println("Dato apilado...\n");
           }
     }

    public Object pop()
     {
      Object dato=null;
      if (tope>-1)
        { 
         dato= pila[tope];
         tope--;
         System.out.println("Dato desapilado..."+((Integer)dato).intValue()+"\n"); 
        }
      else System.out.println("ERROR: La Pila esta vacia. Dato no desapilado!...\n");
      return dato;
     }
 
    public int menu()
     {
      int opc;
      System.out.println("[1] Apilar\n");
      System.out.println("[2] Desapilar\n");
      System.out.println("[3] Salir\n");
      System.out.print("Opcion: ");
      opc=leer.nextInt();
      return opc;
     }  

    public static void main(String args[])
     {
      MiPila p1=new MiPila(7);
      int opc=p1.menu();
      Integer entero;   
      while (opc!=3) 
         {
          switch(opc)
            {
             case 1: System.out.println("OPERACION APILAR");
                     System.out.print("Dame el numero entero a apilar: ");
                     entero=new Integer(p1.leer.nextInt());
                     p1.push(entero);
                     break;

             case 2: System.out.println("OPERACION DESAPILAR");
                     entero=(Integer)p1.pop();
                     break;   
            }
           opc=p1.menu();
         }
     }
   }
