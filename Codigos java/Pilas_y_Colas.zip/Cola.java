
import java.util.Scanner;

class Cola
   {
    public Object[] c;
    int tope, tam;
    public Scanner leer;

    public Cola(int tam)
     {
      leer=new Scanner(System.in);
      c=new Object[tam];
      this.tam=tam;
      tope=-1;
     }

    public void encolar(Object dato)
     {
      if (tope==(tam-1))
        System.out.println("ERROR: La Cola esta llena. Dato no encolado!...\n");
      else {
            tope++;
            c[tope]=dato;
            System.out.println("Dato encolado...\n");
           }
     }

    public Object desencolar()
     {
      Object dato=null;
      if (tope>-1)
        {
         dato= c[0];

         for(int i=0;i<tope;i++)
           {
            c[i]=c[i+1];
           }
         tope--;
         System.out.println("Dato desencolado..."+((Integer)dato).intValue()+"\n");
        }
      else System.out.println("ERROR: La Cola esta vacia. Dato no desencolado!...\n");
      return dato;
     }

    public int menu()
     {
      int opc;
      System.out.println("[1] encolar\n");
      System.out.println("[2] Desencolar\n");
      System.out.println("[3] Salir\n");
      System.out.print("Opcion: ");
      opc=leer.nextInt();
      return opc;
     }

    public static void main(String args[])
     {
      Cola p1=new Cola(7);
      int opc=p1.menu();
      Integer entero;
      while (opc!=3)
         {
          switch(opc)
            {
             case 1: System.out.println("OPERACION ENCOLAR");
                     System.out.print("Dame el numero entero a encolar: ");
                     entero=new Integer(p1.leer.nextInt());
                     p1.encolar(entero);
                     break;

             case 2: System.out.println("OPERACION DESENCOLAR");
                     entero=(Integer)p1.desencolar();
                     break;
            }
           opc=p1.menu();
         }
     }
   }

